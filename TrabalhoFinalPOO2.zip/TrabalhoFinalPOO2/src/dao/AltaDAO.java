package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import modelo.Paciente;

public class AltaDAO {
	
	private Paciente p;
	private Connection con;
	
	public AltaDAO() 
	{

	}
	
	// *-- Athos --*    
	// *-- Lukas Machado(ajustes devido a erros) --*
		public boolean cadastrarPacienteAlta(Paciente pac, String alta){
			try {
				
				//|==================[ MY SQL ]======================|	
				this.p = pac;
				System.out.println("\nCPF Paciente: " + p.getCpf());
				System.out.println("Motivo: " + alta + "\n");
				
				con = ConexaoMySQL.abrirConexaoMySQL();
				PreparedStatement preps = null;
				
				String sql = "insert into alta values(DEFAULT,?,?)";
				
				preps = con.prepareStatement(sql);
				preps.setString(1, p.getCpf());
				preps.setString(2, alta);
				
				int resposta = preps.executeUpdate();
				
				// *-- Lukas Machado --*
				if(resposta == 1) {
					// inseriu alta com sucesso, agora eh necessario remover paciente da lista de internados
					String queryRemocao = "delete from internado where cpfPaciente = '" + p.getCpf() + "'";
					preps = con.prepareStatement(queryRemocao);
					
					int retorno = preps.executeUpdate();
					// verificando se remocao foi executada sem erros
					if(retorno == 1)
						return true;
					else
						return false;
				}else {
					ConexaoMySQL.fecharConexaoMySQL();
					return false;
				}
				
				//|==================================================|
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				ConexaoMySQL.fecharConexaoMySQL();
				return false;
			}
		}
}
