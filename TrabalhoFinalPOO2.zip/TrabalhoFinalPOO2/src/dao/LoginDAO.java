package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import modelo.Usuario;

public class LoginDAO {
private Connection con;
	
	public LoginDAO()
	{
		
	}
	
	public boolean consultaUsuario(Usuario u)
	{
		int retorno = 0;
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		PreparedStatement prepS;
		
		try {
			
			String sql = "select * from login where usuario=? and senha=?";
			prepS = con.prepareStatement(sql);
			
			prepS.setString(1, u.getUsuario());
			prepS.setInt(2, u.getSenha());
			
			ResultSet rs = prepS.executeQuery();
			// se resultado diferente de nulo verifica senha
			if(rs != null)
			{
				rs.next();
				String usuario = rs.getString(1);
				int senha = rs.getInt(2);
				
				// verificando
				if(usuario.equals(u.getUsuario()) && senha == u.getSenha()) 
				{
					retorno = 1; // 1 usuário e senha corretos
				}else
				{
					retorno = 0; // 0 igual usuário ou senha incorretos
				}
			}else
			{
				retorno = 0; // 0 igual usuário ou senha incorretos
			}
			ConexaoMySQL.fecharConexaoMySQL();
		} catch (Exception e) {
			// TODO: handle exception
			retorno = 0;
			e.printStackTrace();
			ConexaoMySQL.fecharConexaoMySQL();
		}
		return retorno > 0 ? true : false;
	}
}
