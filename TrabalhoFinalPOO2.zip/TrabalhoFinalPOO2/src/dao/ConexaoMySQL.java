package dao;

import java.sql.*;

public class ConexaoMySQL {

	// *** N�o esquecer de adicionar a External JAR ao projeto, para poder realizar as opera��es CRUD(create, read, update, delete) ***
	private static Connection con;
	private static String status; 
	
	public ConexaoMySQL()
	{
		
	}
	
	public static Connection abrirConexaoMySQL()
	{
		String servidor = "localhost";
		String banco = "TrabalhoFinal";
		String usuario = "admin";
		String senha = "123456";
		String url = "jdbc:mysql://"+servidor+":3306/"+banco;
		String erro;

		try {
			con = DriverManager.getConnection(url, usuario, senha);
		} catch (Exception e) {
			// TODO: handle exception
			status = "STATUS ----> Falha na conexao com o banco: " + e.getMessage();
			obterStatusConexao();
			return con;
		}
		// verificando a conexao
		if(con != null)
		{
			status = "STATUS ----> Conexao realizada com sucesso!";	
		}else
		{
			status = "STATUS ----> Falha na conexao com o banco!";
			obterStatusConexao();
		}
		return con;	
	}
	
	public static void obterStatusConexao()
	{
		System.out.println(status);
	}
	
	public static void fecharConexaoMySQL()
	{
		try {
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	//testando conexao
	public static void main(String[] args) {
		ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
	}
}
