package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import modelo.Medicamento;

public class MedicamentoDAO {
	
	
	private Connection con;
	

	public MedicamentoDAO() {
		
	}
	
	//Inserir Medicamentos Revisar depois
	public boolean medicamentoSalvar(Medicamento m) {
		
		PreparedStatement prepS;
		con = ConexaoMySQL.abrirConexaoMySQL();
		boolean flag=false;
		String sql = "Insert into Medicamento values(?,?,?,?,?,?)";
		
		try {
			
			//Tem que ver o que o cb é se vai continuar string ou vamos mudar
			prepS=con.prepareStatement(sql);
			prepS = con.prepareStatement(sql);
			prepS.setString(1, m.getCodBarras());
			prepS.setString(2, m.getNome());
			prepS.setString(3, m.getCbGluten());
			prepS.setString(4, m.getCbFrutosMar());
			prepS.setString(5, m.getCbDipirona());
			prepS.setString(6, m.getCbPenicilina());
			
			
			int retorno = prepS.executeUpdate();
			
			if(retorno == 1) {
				flag = true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ConexaoMySQL.fecharConexaoMySQL();
		return flag;
		
	}
	
	//Pesquisa medicamento
	public ArrayList<Medicamento> consultaMedicamentos() {
		
		
		ArrayList<Medicamento> listaMedicamentos = new ArrayList<Medicamento>();
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		
		PreparedStatement prepS;
		
		try {
		String sql = "select m.codBarras"
				+ "	,m.nome"
				+ "	,m.contraGluten"
				+ "	,m.contraFrutosMar"
				+ "	,m.contraDipirona"
				+ "	,m.contraPenicilina"
				+ " from"
				+ " medicamento m;";
				
			
				prepS = con.prepareStatement(sql);
				
				ResultSet resultado = prepS.executeQuery();
				
				while(resultado.next()) {
					String codBarras = resultado.getString("codBarras");
					String nome = resultado.getString("nome");
					String contraGluten = resultado.getString("contraGluten");	
					String contraFrutosMar = resultado.getString("contraFrutosMar");		
					String contraDipirona = resultado.getString("contraDipirona");	
					String contraPenicilina = resultado.getString("contraPenicilina");	
				
					Medicamento m = new Medicamento(codBarras,nome,contraGluten,contraFrutosMar,contraDipirona,contraPenicilina);
					listaMedicamentos.add(m);
				}
				ConexaoMySQL.fecharConexaoMySQL();
				return listaMedicamentos;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
	}
	
	//atualizar Medicamento
	public boolean atualizarMedicamentos(Medicamento m) {
		
		PreparedStatement prepS = null;
		
		
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();

		String sql = "Update medicamento m set nome=?, m.contraGluten=?, m.contraFrutosMar=?, m.contraDipirona=?, m.contraPenicilina=? "
				+ "where m.CodBarras = '" + m.getCodBarras() + "'";
		
		try {
			
			prepS = con.prepareStatement(sql);
			
			prepS.setString(1, m.getNome());
			prepS.setString(2, m.getCbGluten());
			prepS.setString(3, m.getCbFrutosMar());
			prepS.setString(4, m.getCbPenicilina());
			prepS.setString(5, m.getCbDipirona());
			
			prepS.executeUpdate();
			
		} catch(SQLException e1) {
			e1.printStackTrace();
			ConexaoMySQL.fecharConexaoMySQL();
			return false;
		}
		
		ConexaoMySQL.fecharConexaoMySQL();
		return true;
	}
	
	//Remover Medicamento
	public boolean removeMedicamento(String codBarras)
	{
		PreparedStatement prepS = null;
		int res;
		
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		
		String sql = "Delete from Medicamento where codBarras like ?";
		
		try {
			prepS = con.prepareStatement(sql);
			prepS.setString(1, codBarras);
			res=prepS.executeUpdate();
			
			if(res==1)
			{
				ConexaoMySQL.fecharConexaoMySQL();
				return true;
			}
			else
				return false;
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			ConexaoMySQL.fecharConexaoMySQL();
			return false;
		}
	}
		
	//consulta um unico medicamento
	public boolean consultaMedicamentoExiste(String codBarras)
	{
		PreparedStatement prepS = null;
		boolean flag = false;
		
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		
		String sql = "select m.codBarras from medicamento m where m.codBarras = '" + codBarras + "'";
		
		try {
			prepS = con.prepareStatement(sql);
			ResultSet resultado = prepS.executeQuery();

			while(resultado.next())
				flag = true;
			
			return flag;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			ConexaoMySQL.fecharConexaoMySQL();
			return flag;
		}
	
	}
}
