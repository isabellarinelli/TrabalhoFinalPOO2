package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Paciente;

public class PacienteDAO {
	// *-- LUKAS MACHADO e LIVIA REIS --*

	private Paciente p;
	private Connection con;
	
	
	public PacienteDAO()
	{
	}
	
	// Inserir no banco de dados os dados do paciente
	public boolean admitePaciente(Paciente pac)
	{
		this.p= pac;
		boolean flag = false;
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao(); // mostra se a conexao foi bem sucedida
		
		PreparedStatement prepS; // utilizado para rodar o comando sql
		
		try {
			String query = "INSERT INTO PACIENTE VALUES (?,?,?,?,?,?,?,?)"; // ORDEM: String cpf, String nome, String dataNasc, String alergiaGluten, String alergiaFrutosMar,
																	        //        String alergiaDipirona, String alergiaPenicilina, String unidade
			prepS = con.prepareStatement(query); // prepara a query
			
			// inserções
			prepS.setString(1, p.getCpf());
			prepS.setString(2, p.getNome());
			prepS.setDate(3, java.sql.Date.valueOf(p.dataToSQL()));
			prepS.setString(4, p.getAlergiaGluten());
			prepS.setString(5, p.getAlergiaFrutosMar());
			prepS.setString(6, p.getAlergiaDipirona());
			prepS.setString(7, p.getAlergiaPenicilina());
			prepS.setString(8, p.getUnidade());
			
			int retorno = prepS.executeUpdate();
			
			if(retorno == 1)
				flag = true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		ConexaoMySQL.fecharConexaoMySQL();
		return flag;
	}
	
	public boolean internarPaciente(Paciente pac)
	{
		boolean flag = false;
		
		this.p = pac;
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao(); // verificando se esta tudo certo
		PreparedStatement prepS;
		try {
			String query = "INSERT INTO internado values (default,?)";
			prepS = con.prepareStatement(query);
			
			prepS.setString(1, pac.getCpf());
			
			int retorno = prepS.executeUpdate();
			
			if(retorno == 1)
				flag = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		ConexaoMySQL.fecharConexaoMySQL();
		return flag;
	}
	
	// CONSULTA PACIENTES INTERNADOS *-- LUKAS MACHADO --*
	public ArrayList<Paciente> consultaPacientesInternados()
	{
		ArrayList<Paciente> listaPacientesInternados = new ArrayList<Paciente>();
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		
		PreparedStatement prepS;
		
		try {
			String query = "select p.cpf"
					+ "	  ,p.nome"
					+ "      ,p.dataNasc"
					+ "      ,p.alergiaGluten"
					+ "      ,p.alergiaFrutosMar"
					+ "      ,p.alergiaDipirona"
					+ "      ,p.alergiaPenicilina"
					+ "      ,p.unidadeInternacao"
					+ "	from "
					+ "		paciente p inner join internado i on p.cpf = i.cpfPaciente;";
			
			prepS = con.prepareStatement(query);
			
			ResultSet resultado = prepS.executeQuery();
			
			while(resultado.next())
			{
				String cpf = resultado.getString("cpf");
				String nome = resultado.getString("nome");
				String dataNasc = resultado.getString("dataNasc");
				String alergiaG = resultado.getString("alergiaGluten");
				String alergiaF = resultado.getString("alergiaFrutosMar");
				String alergiaD = resultado.getString("alergiaDipirona");
				String alergiaP = resultado.getString("alergiaPenicilina");
				String unidade = resultado.getString("unidadeInternacao");
				
				Paciente p = new Paciente(cpf, nome, dataNasc, alergiaG, alergiaF, alergiaD, alergiaP, unidade);
				listaPacientesInternados.add(p);
			}
			ConexaoMySQL.fecharConexaoMySQL();
			return listaPacientesInternados;
		} catch (Exception e) {
			// TODO: handle exception
			ConexaoMySQL.fecharConexaoMySQL();
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean verificaPacienteInternado(String cpf)
	{
		boolean flag = false;
		
		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao();
		
		PreparedStatement prepS;
		
		String query = "select p.cpf "
				+ "	from "
				+ "    paciente p inner join internado i on i.cpfPaciente = p.cpf"
				+ "	where cpf = '" + cpf + "'";
		
		try {
			prepS = con.prepareStatement(query);
			
			ResultSet resultado = prepS.executeQuery();
			
			while(resultado.next())
			{
				flag = true;
			}
			
			return flag;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}
}
