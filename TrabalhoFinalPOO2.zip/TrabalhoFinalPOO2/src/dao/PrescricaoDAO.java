package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class PrescricaoDAO {
	
	private Connection con;

	public PrescricaoDAO() {

	}

	// Inserir no banco de dados
	public boolean cadastraPrescricao(String cpf, String codMed) {
		
		boolean flag = false;

		SimpleDateFormat formatar = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		PreparedStatement prepS;

		con = ConexaoMySQL.abrirConexaoMySQL();
		ConexaoMySQL.obterStatusConexao(); // mostra se a conexao foi bem sucedida

		try {
			String query = "Insert into Prescricao values (default,?,?,?)";
			
			prepS = con.prepareStatement(query);
			
			// insercoes
			prepS.setString(1, cpf);
			prepS.setString(2, codMed);
			String d = formatar.format(new Date(System.currentTimeMillis()));
			prepS.setString(3, d);

			int retorno = prepS.executeUpdate();
			if (retorno == 1)
				flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
			ConexaoMySQL.fecharConexaoMySQL();
		}
		return flag;
	}

}
