package modelo;

public class Medicamento {

	private String codBarras;
	private String nome;
	private String ciGluten; // ci = Contra Indicado 
	private String ciFrutosMar;	
	private String ciDipirona;
	private String ciPenicilina;


	public Medicamento() {

	}

	public Medicamento(String codBarras, String nome, String ciGluten, String ciFrutosMar, String ciDipirona,
			String ciPenicilina) {
		super();
		this.codBarras = codBarras;
		this.nome = nome;
		this.ciGluten = ciGluten;
		this.ciFrutosMar = ciFrutosMar;
		this.ciDipirona = ciDipirona;
		this.ciPenicilina = ciPenicilina;
	}

	public String getCodBarras() {
		return codBarras;
	}
	public void setCodBarras(String codBarras) {
		this.codBarras = codBarras;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCbGluten() {
		return ciGluten;
	}
	public void setCbGluten(String cbGluten) {
		this.ciGluten = cbGluten;
	}
	public String getCbFrutosMar() {
		return ciFrutosMar;
	}
	public void setCbFrutosMar(String cbFrutosMar) {
		this.ciFrutosMar = cbFrutosMar;
	}
	public String getCbPenicilina() {
		return ciPenicilina;
	}
	public void setCbPenicilina(String cbPenicilina) {
		this.ciPenicilina = cbPenicilina;
	}
	public String getCbDipirona() {
		return ciDipirona;
	}
	public void setCbDipirona(String cbDipirona) {
		this.ciDipirona = cbDipirona;
	}
	
	//Verificar os campos do Medicamento
	public String verficarMedicamentos() {

		String verCodBarras = this.codBarras.replaceAll(" ", "");
		String verNome = this.nome.replaceAll(" ", "");
		
		if (verCodBarras.length() == 20)
		{
			if (verNome.length() >= 5 && verNome.length() <= 50)
			{
				return ""; // retorna string vazia, significando que ta tudo ok
			}else 
			{
				return "Nome deve ter entre 5 a 50 caracteres alfanumericos!";
			}
		}else 
			return "Codigo de Barras deve ter 20 caracteres alfanumericos!";
		}
	

	public String toString() {
		return getCodBarras() + ";"
				+ getNome() + ";"
				+ getCbGluten() + ";" 
				+ getCbFrutosMar() + ";" 
				+ getCbDipirona()+ ";"
				+ getCbPenicilina();
	}

}
