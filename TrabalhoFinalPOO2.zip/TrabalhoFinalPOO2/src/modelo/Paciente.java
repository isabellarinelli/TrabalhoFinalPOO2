package modelo;

import java.util.InputMismatchException;

public class Paciente {
	
	private String cpf;
	private String nome;
	private String dataNasc;
	private String alergiaGluten;
	private String alergiaFrutosMar;
	private String alergiaDipirona;
	private String alergiaPenicilina;
	private String unidade;

	public Paciente(String cpf, String nome, String dataNasc, String alergiaGluten, String alergiaFrutosMar,
			String alergiaDipirona, String alergiaPenicilina, String unidade) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.dataNasc = dataNasc;
		this.alergiaGluten = alergiaGluten;
		this.alergiaFrutosMar = alergiaFrutosMar;
		this.alergiaDipirona = alergiaDipirona;
		this.alergiaPenicilina = alergiaPenicilina;
		this.unidade = unidade;
	}

	public Paciente() {

	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(String dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getAlergiaGluten() {
		return alergiaGluten;
	}
	public void setAlergiaGluten(String alergiaGluten) {
		this.alergiaGluten = alergiaGluten;
	}
	public String getAlergiaFrutosMar() {
		return alergiaFrutosMar;
	}
	public void setAlergiaFrutosMar(String alergiaFrutosMar) {
		this.alergiaFrutosMar = alergiaFrutosMar;
	}
	public String getAlergiaPenicilina() {
		return alergiaPenicilina;
	}
	public void setAlergiaPenicilina(String alergiaPenicilina) {
		this.alergiaPenicilina = alergiaPenicilina;
	}
	public String getAlergiaDipirona() {
		return alergiaDipirona;
	}
	public void setAlergiaDipirona(String alergiaDipirona) {
		this.alergiaDipirona = alergiaDipirona;
	}
	public String getUnidade() {
		return unidade;
	}
	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	
    public boolean isCPF(String CPF) {
        // considera-se erro CPF's formados por uma sequencia de numeros iguais
        if (CPF.equals("00000000000") ||
            CPF.equals("11111111111") ||
            CPF.equals("22222222222") || CPF.equals("33333333333") ||
            CPF.equals("44444444444") || CPF.equals("55555555555") ||
            CPF.equals("66666666666") || CPF.equals("77777777777") ||
            CPF.equals("88888888888") || CPF.equals("99999999999") ||
            (CPF.length() != 11))
            return(false);

        char dig10, dig11;
        int sm, i, r, num, peso;

        // "try" - protege o codigo para eventuais erros de conversao de tipo (int)
        try {
        // Calculo do 1o. Digito Verificador
            sm = 0;
            peso = 10;
            for (i=0; i<9; i++) {
        // converte o i-esimo caractere do CPF em um numero:
        // por exemplo, transforma o caractere '0' no inteiro 0
        // (48 eh a posicao de '0' na tabela ASCII)
            num = (int)(CPF.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                dig10 = '0';
            else dig10 = (char)(r + 48); // converte no respectivo caractere numerico

        // Calculo do 2o. Digito Verificador
            sm = 0;
            peso = 11;
            for(i=0; i<10; i++) {
            num = (int)(CPF.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                 dig11 = '0';
            else dig11 = (char)(r + 48);

        // Verifica se os digitos calculados conferem com os digitos informados.
            if ((dig10 == CPF.charAt(9)) && (dig11 == CPF.charAt(10)))
                 return(true);
            else return(false);
                } catch (InputMismatchException erro) {
                return(false);
            }
    	}
    
    // *-- LUKAS  MACHADO --*
    public boolean verificarCampos() 
    {
    	// verificar cpf
    	if(isCPF(this.cpf))
    	{
    		// verificar nome
    		String nomeSemEspacos = this.nome.replaceAll(" ", "");
    		if(nomeSemEspacos.length() >= 2 && nomeSemEspacos.length() <= 50)
    		{
    			// verificar data
    			if(ehDataNasc(this.dataNasc))
    			{
    				// verifica a unidade
    				if(this.unidade.equals(""))
    				{
    					System.out.println("UNIDADE NAO PREENCHIDA!");
    					return false;
    				}else
    				{
    					return true;
    				}
    			}else
    			{
    				return false;
    			}
    		}else
    		{
    			System.out.println("NOME INVALIDO!\nCONTÉM MENOS DE 2 CARACTERES ALFANUMERICOS OU SUPERIOR A 50 CARACTERES ALFANUMERICOS!");
    			return false;
    		}
    	}else
    	{
    		System.out.println("CPF INVALIDO!");
    		return false;
    	}
    }
    
	@Override
	public String toString() {
		return getCpf() + ";" +
				getNome() + ";" +
				getDataNasc() + ";" +
				getAlergiaGluten() + ";" +
				getAlergiaFrutosMar() + ";" +
				getAlergiaDipirona() + ";" +
				getAlergiaPenicilina() + ";" +
				getUnidade();
	}
	
	public String dataToSQL()
	{
		String[] d = dataNasc.split("/");
		String dia = d[0];
		String mes = d[1];
		String ano = d[2];
				
		return ano + "-" + mes + "-" + dia;
	}
	// *-- LUKAS  MACHADO --*
	public boolean ehDataNasc(String data)
	{
		try {
			// O campo �Data Nasc.� � obrigat�rio e deve aceitar datas no 
			// formato DD/MM/AAAA
			String[] d = data.split("/");
			String dia = d[0];
			String mes = d[1];
			int diaInt = Integer.parseInt(dia);
			int mesInt = Integer.parseInt(mes);
			// verififica dia
			if(dia.length() == 2)
			{	
				if((diaInt >= 1 && diaInt <= 31))
				{
					if(diaInt > 28 && mesInt == 2)
					{
						System.out.println("DATA INVALIDA!");
						return false;
					}else
					{
						// verifica mes
						if(mesInt >= 1 && mesInt <= 12)
						{
							return true;
						}else
						{
							System.out.println("DATA INVALIDA!");
							return false;
						}
					}
				}else
				{
					System.out.println("DATA INVALIDA!");
					return false;
				}
				
			}else
			{
				System.out.println("DATA INVALIDA!");
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("DATA INVALIDA!");
			e.printStackTrace();
			return false;
		}
	}
}
