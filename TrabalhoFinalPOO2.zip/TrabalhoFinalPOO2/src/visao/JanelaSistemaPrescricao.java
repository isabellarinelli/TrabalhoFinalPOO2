package visao;

import java.awt.EventQueue;
import java.awt.MenuBar;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.CardLayout;

public class JanelaSistemaPrescricao extends JFrame {

	private JPanel contentPane;
	private CardLayout card;
	private JPanel telaInicial;
	
	private TelaMedicamentos telaMedicamentos;
	private TelaPacientesInternados telaInternados;
	private TelaAdmissaoPaciente telaAdmissaoPacientes;
	private TelaPrescricao telaPrescrever;
	private TelaAlta telaAlta;
	private TelaLogin telaLogin;
	private TelaLogado telaLogado;
	
	private JMenuItem menuItemListaInternados;
	private JMenuItem menuItemMedicamentos;
	private JMenuItem menuItemAdmissao;
	private JMenuItem menuItemAlta;
	private JMenuItem menuItemPrescrever;
	private JMenuBar menuBar;
	private JMenu menuPrescricao;
	private JMenu menuPacientes;
	
	private JMenu menuLogin;
	private JMenuItem menuItemSair;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaSistemaPrescricao frame = new JanelaSistemaPrescricao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaSistemaPrescricao() {
		setResizable(false);
		setTitle("Sistema de Prescricao Medica");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 480);
		
		// Adi��o de MENUS
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuLogin = new JMenu("Login");
		menuBar.add(menuLogin);
		
		menuItemSair = new JMenuItem("Sair da conta");
		menuItemSair.setEnabled(false);
		menuLogin.add(menuItemSair);
		
		// MENU DE PACIENTE ////////////////////
		menuPacientes = new JMenu("Pacientes");
		menuPacientes.setEnabled(false);
		menuBar.add(menuPacientes);
		
		// MOSTRA PAINEL ADMISSAO - CADASTRA PACIENTES
		// J� IMPLEMENTADO!
		menuItemAdmissao = new JMenuItem("Admissao");
		menuPacientes.add(menuItemAdmissao);
		
		// MOSTRA PAINEL INTERNADOS - MOSTRA LISTA DE INTERNADOS
		// J� IMPLEMENTADO!
		menuItemListaInternados = new JMenuItem("Lista Internados"); 
		menuPacientes.add(menuItemListaInternados);
		
		// MOSTRA PAINEL ALTA - CADASTRA ALTAS
		menuItemAlta = new JMenuItem("Alta");
		menuPacientes.add(menuItemAlta);
		
		////////////////////////////////////////
		
		
		// MENU DE PRESCRI��ES /////////////////
		menuPrescricao = new JMenu("Prescricao");
		menuPrescricao.setEnabled(false);
		menuBar.add(menuPrescricao);
		
		// MOSTRA PAINEL MEDICAMENTO - CADASTRA MEDICAMENTOS
		// J� IMPLEMENTADO!
		menuItemMedicamentos = new JMenuItem("Medicamentos");
		menuPrescricao.add(menuItemMedicamentos);
		
		// MOSTRA PAINEL PRESCREVER - PRESCREVE MEDICAMENTOS PARA PACIENTES
		menuItemPrescrever = new JMenuItem("Prescrever");
		menuPrescricao.add(menuItemPrescrever);
		
		/////////////////////////////////////////
		// Fim da adi��o de MENUS
		
		
		// DEFINI��O DOS PAINEIS E ESTRUTURA DO LAYOUT
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		card = new CardLayout(); // layout para o contentPane
		contentPane.setLayout(card); // definindo layout tipo card

		telaMedicamentos = new TelaMedicamentos(); // painel Tela de Medicamentos
		telaInternados = new TelaPacientesInternados(); // painel Lista de Internados
		telaAlta = new TelaAlta();
		telaAdmissaoPacientes = new TelaAdmissaoPaciente(); // painel de Admiss�o de Pacientes
		telaPrescrever = new TelaPrescricao(); // painel de Prescri��o
		telaLogin = new TelaLogin();
		telaLogado = new TelaLogado();
		
		// Adicionando ao contentPane os pain�is
		contentPane.add(telaLogin, "tLogin");
		contentPane.add(telaLogado,"tLogado");
		contentPane.add(telaMedicamentos, "tMedicamentos");
		contentPane.add(telaInternados, "tInternados");
		contentPane.add(telaAdmissaoPacientes, "tAdmissao");
		contentPane.add(telaPrescrever, "tPrescrever");
		contentPane.add(telaAlta, "tAlta");
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public JPanel getTelaInicial() {
		return telaInicial;
	}

	public void setTelaInicial(JPanel telaInicial) {
		this.telaInicial = telaInicial;
	}

	public TelaMedicamentos getTelaMedicamentos() {
		return telaMedicamentos;
	}

	public void setTelaMedicamentos(TelaMedicamentos telaMedicamentos) {
		this.telaMedicamentos = telaMedicamentos;
	}

	public TelaPacientesInternados getTelaInternados() {
		return telaInternados;
	}

	public void setTelaInternados(TelaPacientesInternados telaInternados) {
		this.telaInternados = telaInternados;
	}

	public CardLayout getCard() {
		return card;
	}

	public JMenuItem getMenuItemListaInternados() {
		return menuItemListaInternados;
	}

	public JMenuItem getMenuItemMedicamentos() {
		return menuItemMedicamentos;
	}

	public JMenuItem getMenuItemAdmissao() {
		return menuItemAdmissao;
	}

	public JMenuItem getMenuItemAlta() {
		return menuItemAlta;
	}

	public JMenuItem getMenuItemPrescrever() {
		return menuItemPrescrever;
	}

	public JMenuBar gettMenuBar() {
		return menuBar;
	}

	public void setMenuBar(JMenuBar menuBar) {
		this.menuBar = menuBar;
	}

	public TelaAdmissaoPaciente getTelaAdmissaoPacientes() {
		return telaAdmissaoPacientes;
	}

	public void setTelaAdmissaoPacientes(TelaAdmissaoPaciente telaAdmissaoPacientes) {
		this.telaAdmissaoPacientes = telaAdmissaoPacientes;
	}

	public TelaPrescricao getTelaPrescricao() {
		return telaPrescrever;
	}

	public void setTelaPrescricao(TelaPrescricao telaPrescricao) {
		this.telaPrescrever = telaPrescricao;
	}

	public TelaAlta getTelaAlta() {
		return telaAlta;
	}

	public void setTelaAlta(TelaAlta telaAlta) {
		this.telaAlta = telaAlta;
	}

	public TelaPrescricao getTelaPrescrever() {
		return telaPrescrever;
	}

	public void setTelaPrescrever(TelaPrescricao telaPrescrever) {
		this.telaPrescrever = telaPrescrever;
	}

	public TelaLogin getTelaLogin() {
		return telaLogin;
	}

	public void setTelaLogin(TelaLogin telaLogin) {
		this.telaLogin = telaLogin;
	}

	public JMenu getMenuLogin() {
		return menuLogin;
	}

	public void setMenuLogin(JMenu menuLogin) {
		this.menuLogin = menuLogin;
	}

	public JMenuItem getMenuItemSair() {
		return menuItemSair;
	}

	public void setMenuItemSair(JMenuItem menuItemSair) {
		this.menuItemSair = menuItemSair;
	}

	public void setMenuItemListaInternados(JMenuItem menuItemListaInternados) {
		this.menuItemListaInternados = menuItemListaInternados;
	}

	public void setMenuItemMedicamentos(JMenuItem menuItemMedicamentos) {
		this.menuItemMedicamentos = menuItemMedicamentos;
	}

	public void setMenuItemAdmissao(JMenuItem menuItemAdmissao) {
		this.menuItemAdmissao = menuItemAdmissao;
	}

	public void setMenuItemAlta(JMenuItem menuItemAlta) {
		this.menuItemAlta = menuItemAlta;
	}

	public void setMenuItemPrescrever(JMenuItem menuItemPrescrever) {
		this.menuItemPrescrever = menuItemPrescrever;
	}

	public JMenu getMenuPrescricao() {
		return menuPrescricao;
	}

	public void setMenuPrescricao(JMenu menuPrescricao) {
		this.menuPrescricao = menuPrescricao;
	}

	public JMenu getMenuPacientes() {
		return menuPacientes;
	}

	public void setMenuPacientes(JMenu menuPacientes) {
		this.menuPacientes = menuPacientes;
	}

	public TelaLogado getTelaLogado() {
		return telaLogado;
	}

	public void setTelaLogado(TelaLogado telaLogado) {
		this.telaLogado = telaLogado;
	}

	public void limpaTela() {
		// tela paciente
		telaAdmissaoPacientes.getFieldCpf().setText("");
		telaAdmissaoPacientes.getFieldDataNasc().setText("");
		telaAdmissaoPacientes.getFieldNome().setText("");
		telaAdmissaoPacientes.getComboUnidade().setSelectedIndex(0);
		telaAdmissaoPacientes.getChkDipirona().setSelected(false);
		telaAdmissaoPacientes.getChkFrutosDoMar().setSelected(false);
		telaAdmissaoPacientes.getChkGluten().setSelected(false);
		telaAdmissaoPacientes.getChkPenicilina().setSelected(false);
	}
}
