package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.SwingConstants;

public class TelaAlta extends JPanel {
	
	private JTextField fieldCpf;
	private JButton btnSalvar;
	private JButton btnCancelar;
	private JComboBox<String> comboBoxMotivo;

	/**
	 * Create the panel.
	 */
	public TelaAlta() {
		setLayout(new MigLayout("", "[][][grow][][][][grow][][]", "[][][][][][][][][][][][][][][grow][]"));
		setBounds(0,0,640,480);
		JLabel labelCpf = new JLabel("CPF:");
		labelCpf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(labelCpf, "cell 1 7");
		
		fieldCpf = new JTextField();
		fieldCpf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(fieldCpf, "cell 2 7,growx");
		fieldCpf.setColumns(10);
		
		JLabel labelMotivo = new JLabel("Motivo:");
		labelMotivo.setHorizontalAlignment(SwingConstants.LEFT);
		labelMotivo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(labelMotivo, "cell 1 8");
		
		comboBoxMotivo = new JComboBox<String>();
		comboBoxMotivo.addItem("");
		comboBoxMotivo.addItem("Cura");
		comboBoxMotivo.addItem("Transferencia");
		comboBoxMotivo.addItem("Obito");
		comboBoxMotivo.setRequestFocusEnabled(false);
		comboBoxMotivo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(comboBoxMotivo, "cell 2 8,growx");
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSalvar.setFocusPainted(false);
		add(btnSalvar, "cell 0 15");
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCancelar.setFocusPainted(false);
		add(btnCancelar, "cell 1 15");

	}

	public JTextField getTextCpf() {
		return fieldCpf;
	}

	public void setTextCpf(JTextField textCpf) {
		this.fieldCpf = textCpf;
	}

	public JButton getBtnSalvar() {
		return btnSalvar;
	}

	public void setBtnSalvar(JButton btnSalvar) {
		this.btnSalvar = btnSalvar;
	}

	public JButton getBtnCancelar() {
		return btnCancelar;
	}

	public void setBtnCancelar(JButton btnCancelar) {
		this.btnCancelar = btnCancelar;
	}

	public JComboBox<String> getComboBoxMotivo() {
		return comboBoxMotivo;
	}

	public void setComboBoxMotivo(JComboBox<String> comboBoxMotivo) {
		this.comboBoxMotivo = comboBoxMotivo;
	}
	
	public void limpaTela()
	{
		 fieldCpf.setText("");
		 comboBoxMotivo.setSelectedIndex(0);
	}
}
