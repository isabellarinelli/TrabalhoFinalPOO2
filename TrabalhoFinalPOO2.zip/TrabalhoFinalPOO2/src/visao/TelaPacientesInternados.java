package visao;

import javax.swing.JPanel;
import javax.swing.JLabel;
import net.miginfocom.swing.MigLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class TelaPacientesInternados extends JPanel {
	private JButton btnSalvar;
	private JButton btnCancelar;
	private JScrollPane scrollNome;
	private JScrollPane scrollUnidade;
	private JScrollPane scrollData;
	private JScrollPane scrollAlergia;
	private JTextArea textNome;
	private JTextArea textUnidade;
	private JTextArea textData;
	private JTextArea textAlergia;
	
	

	public TelaPacientesInternados() {
		setLayout(new MigLayout("", "[167.00px,grow][144.00,grow][142.00,grow][141.00,grow]", "[14px][][grow][]"));
		setBounds(0, 0, 640, 480);
		JLabel lblTitulo = new JLabel("Lista de Internados");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
		add(lblTitulo, "cell 0 0,alignx left,aligny top");
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(lblNome, "cell 0 1");
		
		JLabel lblUnidade = new JLabel("Unidade:");
		lblUnidade.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(lblUnidade, "cell 1 1");
		
		JLabel lblDataNasc = new JLabel("Data Nasc:");
		lblDataNasc.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(lblDataNasc, "cell 2 1");
		
		JLabel lblAlergias = new JLabel("Alergias:");
		lblAlergias.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(lblAlergias, "cell 3 1");
		
		scrollNome = new JScrollPane();
		add(scrollNome, "cell 0 2,grow");
		
		textNome = new JTextArea();
		textNome.setEditable(false);
		scrollNome.setViewportView(textNome);
		
		scrollUnidade = new JScrollPane();
		add(scrollUnidade, "cell 1 2,grow");
		
		textUnidade = new JTextArea();
		textUnidade.setEditable(false);
		scrollUnidade.setViewportView(textUnidade);
		
		scrollData = new JScrollPane();
		add(scrollData, "cell 2 2,grow");
		
		textData = new JTextArea();
		textData.setEditable(false);
		scrollData.setViewportView(textData);
		
		scrollAlergia = new JScrollPane();
		add(scrollAlergia, "cell 3 2,grow");
		
		textAlergia = new JTextArea();
		textAlergia.setEditable(false);
		scrollAlergia.setViewportView(textAlergia);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSalvar.setEnabled(false);
		add(btnSalvar, "cell 0 3");
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnCancelar, "cell 1 3");
		
	}
	
	
	public JButton getBtnSalvar() {
		return btnSalvar;
	}

	public void setBtnSalvar(JButton btnSalvar) {
		this.btnSalvar = btnSalvar;
	}

	public JButton getBtnCancelar() {
		return btnCancelar;
	}

	public void setBtnCancelar(JButton btnCancelar) {
		this.btnCancelar = btnCancelar;
	}
	
	public JTextArea getTextNome() {
		return textNome;
	}


	public void setTextNome(JTextArea textNome) {
		this.textNome = textNome;
	}


	public JTextArea getTextUnidade() {
		return textUnidade;
	}


	public void setTextUnidade(JTextArea textUnidade) {
		this.textUnidade = textUnidade;
	}


	public JTextArea getTextData() {
		return textData;
	}


	public void setTextData(JTextArea textData) {
		this.textData = textData;
	}


	public JTextArea getTextAlergia() {
		return textAlergia;
	}


	public void setTextAlergia(JTextArea textAlergia) {
		this.textAlergia = textAlergia;
	}


	public void limpaTela()
	{
		this.textNome.setText("");
		this.textUnidade.setText("");
		this.textData.setText("");
		this.textAlergia.setText("");
	}
}
