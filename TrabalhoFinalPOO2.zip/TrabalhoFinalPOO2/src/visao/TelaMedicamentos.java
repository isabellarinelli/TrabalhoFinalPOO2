package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class TelaMedicamentos extends JPanel {
	private JTextField fieldCodBarras;
	private JTextField fieldNome;
	private JButton btnSalvar;
	private JButton btnCancelar;
	private JCheckBox chkGluten;
	private JCheckBox chkFrutosMar;
	private JCheckBox chkPenicilina;
	private JCheckBox chkDipirona;
	private JButton btnRemover;
	private JButton btnAtualizar;
	private JButton btnConsultar;
	

	/**
	 * Create the panel.
	 */
	public TelaMedicamentos() {
		setLayout(new MigLayout("", "[145.00][138.00][39.00][64.00][41.00][193.00][][233.00]", "[][][][][][][][][][][][][][][][]"));
		setBounds(0,0,640,480);
		
		JLabel lblDadosMedicamentos = new JLabel("Dados do Medicamento");
		lblDadosMedicamentos.setFont(new Font("Tahoma", Font.BOLD, 16));
		add(lblDadosMedicamentos, "cell 0 1 4 1");
		
		JLabel lblCodBarras = new JLabel("Codigo de Barras:");
		lblCodBarras.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lblCodBarras, "cell 0 3");
		
		fieldCodBarras = new JTextField();
		fieldCodBarras.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(fieldCodBarras, "cell 1 3 4 1,growx");
		fieldCodBarras.setColumns(20);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnConsultar, "cell 5 3,growx");
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lblNome, "cell 0 4,alignx left");
		
		fieldNome = new JTextField();
		fieldNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(fieldNome, "cell 1 4 7 1,growx");
		fieldNome.setColumns(10);
		
		JLabel lblAlergia = new JLabel("Contraindicado para as alergias:");
		lblAlergia.setFont(new Font("Tahoma", Font.BOLD, 16));
		add(lblAlergia, "cell 0 7 5 1");
		
		chkGluten = new JCheckBox("Gluten");
		chkGluten.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(chkGluten, "cell 0 8,alignx left");
		
		
		chkFrutosMar = new JCheckBox("Frutos do Mar");
		chkFrutosMar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(chkFrutosMar, "cell 2 8 2 1,alignx left");
		
		chkPenicilina = new JCheckBox("Penicilina");
		chkPenicilina.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(chkPenicilina, "cell 5 8,alignx left");
		
		chkDipirona = new JCheckBox("Dipirona");
		chkDipirona.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(chkDipirona, "cell 7 8,alignx left");
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnSalvar, "cell 0 15 2 1,growx");
		
		btnAtualizar = new JButton("Atualizar");
		btnAtualizar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnAtualizar, "cell 2 15 2 1,growx");
		
		btnRemover = new JButton("Remover");
		btnRemover.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnRemover, "cell 5 15,growx");
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		add(btnCancelar, "cell 7 15,growx");

		
		
	}

	

	public JTextField getFieldCodBarras() {
		return fieldCodBarras;
	}



	public void setFieldCodBarras(JTextField fieldCodBarras) {
		this.fieldCodBarras = fieldCodBarras;
	}



	public JTextField getFieldNome() {
		return fieldNome;
	}



	public void setFieldNome(JTextField fieldNome) {
		this.fieldNome = fieldNome;
	}


	

	public JCheckBox getChkGluten() {
		return chkGluten;
	}



	public void setChkGluten(JCheckBox chkGluten) {
		this.chkGluten = chkGluten;
	}



	public JCheckBox getChkFrutosMar() {
		return chkFrutosMar;
	}



	public void setChkFrutosMar(JCheckBox chkFrutosMar) {
		this.chkFrutosMar = chkFrutosMar;
	}



	public JCheckBox getChkPenicilina() {
		return chkPenicilina;
	}



	public void setChkPenicilina(JCheckBox chkPenicilina) {
		this.chkPenicilina = chkPenicilina;
	}



	public JCheckBox getChkDipirona() {
		return chkDipirona;
	}



	public void setChkDipirona(JCheckBox chkDipirona) {
		this.chkDipirona = chkDipirona;
	}



	public JButton getBtnSalvar() {
		return btnSalvar;
	}



	public void setBtnSalvar(JButton btnSalvar) {
		this.btnSalvar = btnSalvar;
	}



	public JButton getBtnCancelar() {
		return btnCancelar;
	}



	public void setBtnCancelar(JButton btnCancelar) {
		this.btnCancelar = btnCancelar;
	}

	


	public JButton getBtnRemover() {
		return btnRemover;
	}



	public void setBtnRemover(JButton btnRemover) {
		this.btnRemover = btnRemover;
	}



	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}



	public void setBtnAtualizar(JButton btnAtualizar) {
		this.btnAtualizar = btnAtualizar;
	}



	public JButton getBtnConsultar() {
		return btnConsultar;
	}



	public void setBtnConsultar(JButton btnConsultar) {
		this.btnConsultar = btnConsultar;
	}



	public void limpaTela() {
		fieldCodBarras.setText("");
		fieldNome.setText("");
		chkGluten.setSelected(false);
		chkFrutosMar.setSelected(false);
		chkDipirona.setSelected(false);
		chkPenicilina.setSelected(false);
	}
}

