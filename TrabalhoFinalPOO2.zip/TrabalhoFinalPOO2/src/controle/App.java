package controle;

import dao.AltaDAO;
import dao.LoginDAO;
import dao.MedicamentoDAO;
import dao.PacienteDAO;
import dao.PrescricaoDAO;
import modelo.Medicamento;
import modelo.Paciente;
import modelo.Usuario;
import visao.JanelaSistemaPrescricao;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JanelaSistemaPrescricao janela = new JanelaSistemaPrescricao();
		janela.setVisible(true);
		janela.setLocationRelativeTo(null);

		ControleSistemaPrescricao controle;
		ControleLogin controleLogin;
		
		Paciente pac = new Paciente();
		PacienteDAO pacDao = new PacienteDAO();
		AltaDAO altaDAO = new AltaDAO();
		Medicamento med = new Medicamento();
		MedicamentoDAO mDAO = new MedicamentoDAO();
		PrescricaoDAO prescDao = new PrescricaoDAO();
		Usuario usu = new Usuario();
		LoginDAO lgDao = new LoginDAO();
		
	
		controle = new ControleSistemaPrescricao(janela, pac, med, pacDao, altaDAO, mDAO, prescDao);
		controleLogin = new ControleLogin(janela,usu,lgDao);
	}

}
