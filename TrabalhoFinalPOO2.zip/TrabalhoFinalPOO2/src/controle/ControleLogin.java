package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import dao.LoginDAO;
import modelo.Usuario;
import visao.JanelaSistemaPrescricao;

public class ControleLogin implements ActionListener, KeyListener{

	private JanelaSistemaPrescricao janela;
	private Usuario usu;
	private LoginDAO loginDao;
	private String usuarioLogado = "user test";
	
	public ControleLogin(JanelaSistemaPrescricao janela, Usuario u, LoginDAO loginDAO) {
		super();
		this.janela = janela;
		this.usu = u;
		this.loginDao = loginDAO;
		// janela LOGIN
		this.janela.getMenuItemSair().addActionListener(this);
		this.janela.getTelaLogin().getBtnLimpar().addActionListener(this);
		this.janela.getTelaLogin().getBtnLogar().addActionListener(this);
		this.janela.getTelaLogin().getBtnDesbloquearAcessosSem().addActionListener(this);
		this.janela.getTelaLogin().getSenhaLogin().addKeyListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		// LOGIN PARA TESTES
		if(e.getActionCommand().equals("Desbloquear acessos sem logar (Apenas para testes)"))
		{
			//liberar menus
			this.janela.getMenuPacientes().setEnabled(true);
			this.janela.getMenuPrescricao().setEnabled(true);
			this.janela.getMenuItemSair().setEnabled(true);
			//trocar janela para logado
			this.janela.getTelaLogado().getLabelUsuario().setText("user test");
			this.janela.getCard().show(this.janela.getContentPane(), "tLogado");
			this.janela.getTelaLogin().getUsuarioLogin().setText("");
			this.janela.getTelaLogin().getSenhaLogin().setText("");
		}else if(e.getActionCommand().equals("Sair da conta")) // saindo da conta
		{
			this.janela.getTelaLogin().getUsuarioLogin().setText("");
			this.janela.getTelaLogin().getSenhaLogin().setText("");
			this.janela.getMenuPacientes().setEnabled(false);
			this.janela.getMenuPrescricao().setEnabled(false);
			this.janela.getMenuItemSair().setEnabled(false);
			this.janela.getTelaLogado().getLabelUsuario().setText("none");
			this.janela.getCard().show(this.janela.getContentPane(), "tLogin");
		}
		
		/////////////-- Login do Usuário --//////////////
		if(e.getActionCommand().equals("Logar"))
		{
			if(autenticaUsuario())
			{
				//liberar menus
				this.janela.getMenuPacientes().setEnabled(true);
				this.janela.getMenuPrescricao().setEnabled(true);
				this.janela.getMenuItemSair().setEnabled(true);
				//trocar janela para logado
				this.janela.getTelaLogado().getLabelUsuario().setText(usuarioLogado);
				this.janela.getCard().show(this.janela.getContentPane(), "tLogado");
			}
		}else if(e.getActionCommand().equals("Limpar"))
		{
			this.janela.getTelaLogin().getUsuarioLogin().setText("");
			this.janela.getTelaLogin().getSenhaLogin().setText("");
		}
	}

	// permitindo 'clicar' no botão pela tecla ENTER
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			if(e.getKeyCode()==KeyEvent.VK_ENTER)
			{
				if(autenticaUsuario())
				{
					//liberar menus
					this.janela.getMenuPacientes().setEnabled(true);
					this.janela.getMenuPrescricao().setEnabled(true);
					this.janela.getMenuItemSair().setEnabled(true);
					//trocar janela para logado
					this.janela.getTelaLogado().getLabelUsuario().setText(usuarioLogado);
					this.janela.getCard().show(this.janela.getContentPane(), "tLogado");
				}
			}
		}
		
	// verifica usuario e senha
	public boolean autenticaUsuario()
	{
		System.out.println("Autenticando...");
		
		// verificando campos
		try {
			String usuario = janela.getTelaLogin().getUsuarioLogin().getText();
			int senha = Integer.parseInt(String.valueOf(janela.getTelaLogin().getSenhaLogin().getPassword()));
			System.out.println("usuario:" +usuario+"\nsenha: "+senha);
			usu = new Usuario(usuario, senha); // cria usuario
			
			// faz consulta
			if(loginDao.consultaUsuario(usu))
			{
				usuarioLogado = usuario;
				JOptionPane.showMessageDialog(null, "Usuario Autenticado!", "Autenticacao", 1,new ImageIcon(ControleLogin.class.getResource("/imagens/ok.png"))); 
				System.out.println("Usuario Autenticado!");
				return true;
			}else // erro no sql
			{
				JOptionPane.showMessageDialog(null, "Usuario nao Autenticado!\nSenha ou usuario invalido!", "Autenticacao", 0, new ImageIcon(ControleLogin.class.getResource("/imagens/error.png")));
				System.out.println("Usuario nao autenticado!");
				return false;
			}
		} catch (Exception e) { // erro nos campos
			// TODO: handle exception
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Campos em branco ou invalidos!", "Autenticacao", 0, new ImageIcon(ControleLogin.class.getResource("/imagens/warning.png")));
			System.out.println("Usuario nao autenticado!");
			return false;
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
