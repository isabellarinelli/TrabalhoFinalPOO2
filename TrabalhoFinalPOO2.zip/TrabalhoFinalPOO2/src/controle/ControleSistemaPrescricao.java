package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import dao.AltaDAO;
import dao.MedicamentoDAO;
import dao.PacienteDAO;
import dao.PrescricaoDAO;
import modelo.Medicamento;
import modelo.Paciente;
import visao.JanelaSistemaPrescricao;

public class ControleSistemaPrescricao implements ActionListener, KeyListener {
	
	private Paciente pac;
	private PacienteDAO pacDao;
	private AltaDAO altaDAO;
	private Medicamento med;
	private MedicamentoDAO mDAO;
	private PrescricaoDAO prescDAO;
	private JanelaSistemaPrescricao janela;
	DateTimeFormatter horaAtualFormatada = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	
	private int painelAtivo = -1;
	private String gluten;
	private String dipirona;
	private String frutos;
	private String penicilina;
	
	private String mGluten;
	private String mFrutosMar;
	private String mPenicilina;
	private String mDipirona;
	

	
	/* PARA DESCOBRIR QUAL JPANEL ESTA VISIVEL NO CONTENTPANE
		SER  NECESSARIO UMA LOGICA UTILIZANDO UMA VARIAVEL GLOBAL NESTA CLASSE
		DEFININDO VALORES NUM RICOS PARA CADA JPANEL.
		TENTEI ENCONTRAR UMA FORMA DE DESCOBRIR QUAL PAINEL ESTA ATIVO PROCURANDO
		NO GOOGLE, MAS NAO ENCONTREI SOLUCOES INTERESSANTES, PORTANTO CRIEI ESTA LOGICA.
		*-- LUKAS MACHADO --*
		
		EXEMPLO:
		PAINEL ADMISSAO     - valor - painelAtivo = 1
		PAINEL INTERNADOS   - valor - painelAtivo = 2
		PAINEL ALTA         - valor - painelAtivo = 3
		PAINEL MEDICAMENTOS - valor - painelAtivo = 4
		PAINEL PRESCREVER   - valor - painelAtivo = 5
		
		ENT O SER  DEFINIDO O VALOR DA VARI VEL painelAtivo 
		AO CLICAR PARA VER O PAINEL ESCOLHIDO.
		
		EX.:
		CLICA EM ADMISS O->ALTERA O VALOR DA VARI VEL painelAtivo para 1 (VALOR PADR O   -1);
		AO VOLTAR A TELA INICIAL DEFINE O VALOR COMO -1 NOVAMENTE.
		*-- LUKAS MACHADO --*
	 */	
	
	public ControleSistemaPrescricao(JanelaSistemaPrescricao j, Paciente pac, Medicamento med, PacienteDAO pacDAO, AltaDAO altaDAO, MedicamentoDAO mDAO, PrescricaoDAO prescDAO)
	{
		this.janela = j;
		this.pacDao = pacDAO;
		this.pac = pac;
		this.altaDAO = altaDAO;
		this.mDAO = mDAO;
		this.med = med;
		this.prescDAO = prescDAO;
		
		this.janela.getTelaPrescricao().getFieldCpf().addKeyListener(this); 
		this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().addKeyListener(this);
		
		this.janela.getMenuItemListaInternados().addActionListener(this);                     // MENUITEM LISTA INTERNADOS recebe o actionlistener desta classe
		this.janela.getMenuItemMedicamentos().addActionListener(this);                        // MENUITEM MEDICAMENTOS recebe o actionlistener desta classe
		this.janela.getMenuItemAdmissao().addActionListener(this);                            // MENUITEM ADMISSAO recebe o actionlistener desta classe
		this.janela.getMenuItemPrescrever().addActionListener(this);                          // MENUITEM PRESCREVER recebe o actionlistener desta classse
		this.janela.getMenuItemAlta().addActionListener(this);                                // MENUITEM ALTA recebe o actionlistener desta classe
		this.janela.getTelaAlta().getBtnCancelar().addActionListener(this);                   // CANCELAR DE ALTA
		this.janela.getTelaPrescricao().getBtnCancelar().addActionListener(this);             // CANCELAR DE PRESCRICAO
		this.janela.getTelaInternados().getBtnCancelar().addActionListener(this);             // CANCELAR DE INTERNADOS
		this.janela.getTelaAdmissaoPacientes().getBtnCancelar().addActionListener(this);      // CANCELAR DE ADMISSAO
		this.janela.getTelaMedicamentos().getBtnCancelar().addActionListener(this);           // CANCELAR DE MEDICAMENTOS
		this.janela.getTelaAlta().getBtnSalvar().addActionListener(this);                     // SALVAR DE ALTA
		this.janela.getTelaPrescricao().getBtnSalvar().addActionListener(this);               // SALVAR DE PRESCRICAO
		this.janela.getTelaAdmissaoPacientes().getBtnSalvar().addActionListener(this);        // SALVAR DE ADMISSAO
		this.janela.getTelaMedicamentos().getBtnSalvar().addActionListener(this);             // SALVAR DE MEDICAMENTOS
		this.janela.getTelaMedicamentos().getBtnAtualizar().addActionListener(this);
		this.janela.getTelaMedicamentos().getBtnRemover().addActionListener(this);
		this.janela.getTelaMedicamentos().getBtnConsultar().addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		// EVENTO DE TROCA DE PAINEL
		if(e.getActionCommand().equals("Lista Internados"))
		{	
			painelAtivo = 2;// definir qual painel esta ativo
			System.out.println("Mostrando painel internados...");
			this.janela.getCard().show(this.janela.getContentPane(), "tInternados");
			escondeMenu(); // esconde o menu
			this.janela.setTitle("Lista de Internados"); // titulo da tela

			// pega lista de pacientes
			ArrayList<Paciente> pacientesInternados = pacDao.consultaPacientesInternados(); 
			preencheInternados(pacientesInternados);
		}else 
			if(e.getActionCommand().equals("Cancelar")) 
			{	
				// APAGA DADOS E VOLTA PARA TELA INICIAL
				System.out.println("Limpando campos...");
				this.janela.getTelaAdmissaoPacientes().limpaTela(); // Limpa tela de admiss o de paciente
				this.janela.getTelaInternados().limpaTela(); // limpa tela de internados
				this.janela.getTelaMedicamentos().limpaTela(); // limpa tela de medicamentos
				this.janela.getTelaPrescricao().limpaTela();  // limpa tela de prescricao
				this.janela.getTelaAlta().limpaTela(); // limpa tela de alta
				System.out.println("Voltando a tela inicial...");
				this.janela.getCard().show(this.janela.getContentPane(), "tLogado");
				this.janela.setTitle("Sistema de Prescricao Medica"); // Muda o t tulo para o t tulo do painel
				this.janela.gettMenuBar().setVisible(true); // volta o menu
				painelAtivo = -1; // nenhum painel ativo
			}else 
				if(e.getActionCommand().equals("Admissao"))	
				{
					painelAtivo = 1;// definir qual painel esta ativo
					System.out.println("Mostrando painel admissao...");
					this.janela.getCard().show(this.janela.getContentPane(), "tAdmissao");
					this.janela.setTitle("Admissao"); // Muda o titulo para o titulo do painel
					escondeMenu(); // esconde o menu
				}else
					if(e.getActionCommand().equals("Medicamentos")) 
					{
						painelAtivo = 4;// definir qual painel esta ativo
						System.out.println("Mostrando painel medicamentos");
						this.janela.getCard().show(this.janela.getContentPane(), "tMedicamentos");
						this.janela.setTitle("Medicamentos"); // Muda o titulo para o titulo do painel
						escondeMenu(); // esconde o menu
					}else
						if(e.getActionCommand().equals("Salvar")) 
						{
							System.out.println("cadastrando...");
							// verificando qual painel esta ativo para o botao salvar
							switch (painelAtivo) {
								case 1: // PAINEL ADMISSAO 	// *-- LUKAS  MACHADO --*
								{
									System.out.println("Mostrando painel admissao...");
									
									// Preenche campos 
									String cpf = this.janela.getTelaAdmissaoPacientes().getFieldCpf().getText();
									String nome = this.janela.getTelaAdmissaoPacientes().getFieldNome().getText();
									String data = this.janela.getTelaAdmissaoPacientes().getFieldDataNasc().getText();
									String unidade = this.janela.getTelaAdmissaoPacientes().getComboUnidade().getSelectedItem().toString();
									if(setAlergiasPaciente())
									{
										// Verifica campos
										pac = new Paciente(cpf, nome, data, gluten, frutos, dipirona, penicilina, unidade);
										if(pac.verificarCampos())
										{
											// Cadastrando
											System.out.println("Cadastrando paciente...");
											if(pacDao.admitePaciente(pac))
											{
												JOptionPane.showMessageDialog(janela,"Paciente Cadastrado com Sucesso","Cadastro",1,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
												System.out.println("Paciente cadastrado!");
												janela.limpaTela();
												// Internando...
												if(pacDao.internarPaciente(pac))
													JOptionPane.showMessageDialog(janela,"Paciente Internado!","Cadastro",1,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
												else
													JOptionPane.showMessageDialog(janela,"Nao foi possivel internar o paciente!","Cadastro",1,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
											}else
											{
												JOptionPane.showMessageDialog(janela,"Paciente ja cadastrado!","Cadastro",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												// Internando...
												if(pacDao.verificaPacienteInternado(cpf)==false)
												{
													if(pacDao.internarPaciente(pac))
														JOptionPane.showMessageDialog(janela,"Paciente Internado!","Cadastro",1,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
													else
														JOptionPane.showMessageDialog(janela,"Nao foi possivel internar o paciente!","Cadastro",1,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												}else
												{
													JOptionPane.showMessageDialog(janela,"Paciente ja esta internado!","Cadastro",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
													System.out.println("Paciente Nao internado!");
												}
												janela.limpaTela();
											}
										}else 
										{
											JOptionPane.showMessageDialog(janela,"Paciente nao Cadastrado\nVerifique o CPF informado!","Cadastro",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
											System.out.println("Cadastro de paciente nao concluido...");
										}
									}else
									{
										JOptionPane.showMessageDialog(janela,"Problema no cadastro de alergias","Cadastro",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
										System.out.println("Cadastro de alergias nao concluido!");
									}
									break;
								}
								case 3: // PAINEL ALTA // *-- Athos --*
								{
									System.out.println("Mostrando painel alta...");
									String cpf = this.janela.getTelaAlta().getTextCpf().getText(); // pega cpf
									String motivo = this.janela.getTelaAlta().getComboBoxMotivo().getSelectedItem().toString(); // pega motivo
									ArrayList<Paciente> pacientes = pacDao.consultaPacientesInternados(); // TODOS OS PACIENTES
									
									boolean cpfEncontrado = false;
									// verifica cpf
									if(ehCPF(cpf)) 
									{
										// verifica campo Motivo
										if(!motivo.equals(""))
										{
											System.out.println("Cadastrando alta...");
											for(Paciente p : pacientes)
											{
												//se o cpf digitado for encontrado na lista dos pacientes, coloca este paciente na lista de altas *-- LUKAS MACHADO --*
												if(p.getCpf().equals(cpf))
												{
													if(altaDAO.cadastrarPacienteAlta(p, motivo)) // cadastra o paciente em altas
													{
														JOptionPane.showMessageDialog(janela,"Alta realizada!","Alta",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
														cpfEncontrado = true;
														janela.getTelaAlta().limpaTela();
														break;
													}else
													{
														JOptionPane.showMessageDialog(janela,"Erro ao realizar alta!","Alta",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
														janela.getTelaAlta().limpaTela();
													}	
												}
											}
											// se cpf foi encontrado tudo ok, sen o retorna mensagem ao usu rio
											if(!cpfEncontrado)
											{
												JOptionPane.showMessageDialog(janela,"CPF nao encontrado!","Alta",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
												this.janela.getTelaAlta().limpaTela();
											}
										}else {
											JOptionPane.showMessageDialog(janela,"O campo Motivo esta em branco!","Alta",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
										}			
									}else
									{
										JOptionPane.showMessageDialog(janela,"CPF invalido ou em branco!","Alta",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
									}
									break;
								}
								
								case 4: // PAINEL MEDICAMENTOS // *--VITHOR DELAVI--*
								{
									System.out.println("Mostrando painel medicamentos...");
									
									//Preenche campos
									String cod = this.janela.getTelaMedicamentos().getFieldCodBarras().getText();
									String nome = this.janela.getTelaMedicamentos().getFieldNome().getText();
								
									//cadastro de alergia
									if(alergiasMedicamento()) 
									{
										System.out.println("Cadastrando medicamento...");
										//Cadastro
										
										med = new Medicamento(cod, nome, mGluten, mFrutosMar, mDipirona, mPenicilina);
										String verificacaoCampos = med.verficarMedicamentos();
										if(verificacaoCampos.equals("")) 
										{
											if(mDAO.medicamentoSalvar(med))
											{
												JOptionPane.showMessageDialog(janela, "Medicamento cadastrado com sucesso!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
												System.out.println("Medicamento Cadastrado com sucesso!");
												this.janela.getTelaMedicamentos().limpaTela();
											}else
											{
												JOptionPane.showMessageDialog(janela, "Erro ao cadastrar medicamento!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												System.out.println("Erro ao Cadastrar Medicamento!");
											}
										}else // erro ao verificar os campos
										{
											// informa o usu rio que digitou algo errado nos campos
											JOptionPane.showMessageDialog(janela, verificacaoCampos,"Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
										}
									}else
									{
										System.out.println("Erro no Cadastro de alergias medicamento!");
									}
									break;
								}
								case 5: // PAINEL PRESCREVER
								{
									// Pegando dados 
									String cpf = this.janela.getTelaPrescricao().getFieldCpf().getText();
									String codMed = this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().getText();
									boolean pacienteExiste = pacDao.verificaPacienteInternado(cpf);
									boolean codBarrasEncontrado = false;
									
									// Se campos estiverem vazios nao cadastra
									if(!(cpf.equals("") || codMed.equals("")) && pacienteExiste)
									{
										// Pega lista de medicamentos
										ArrayList<Medicamento> listaMedicamentos = mDAO.consultaMedicamentos();
										//Verifica se a lista esta nula
										if(listaMedicamentos != null)
										{
											// Lista nao esta nula, entao verificaremos o codigo de barras
											for(Medicamento m : listaMedicamentos)
											{
												// Procura medicamento
												if(m.getCodBarras().equals(codMed))
												{
													codBarrasEncontrado = true;
													// achou o codigo, agora verificaremos as alergias
													if(pacienteAlergico(m))
													{
														//   necessario limpar os campos pois o paciente alergico
														this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().setText("");
														this.janela.getTelaPrescricao().getFieldNomeMedicamento().setText("");
														JOptionPane.showMessageDialog(janela, "Paciente alergico ao medicamento","Prescricao",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
														System.out.println("Paciente alergico ao medicamento!");
														break;
													}else
													{
														// Paciente nao alergico ao medicamento, podemos partir para a prescricao
														System.out.println("Prescrevendo medicamento...");	
														
														if(prescDAO.cadastraPrescricao(cpf, codMed))
														{
															JOptionPane.showMessageDialog(janela, "Medicamento Prescrito!","Prescricao",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
															janela.getTelaPrescrever().limpaTela();
															System.out.println("Medicamento prescrito!");
															this.janela.getTelaMedicamentos().limpaTela();
														}else
														{
															JOptionPane.showMessageDialog(janela, "Erro ao prescrever medicamento","Prescricao",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
															System.out.println("Ihh... Nao o deu pra prescrever!");
														}
													}
												}
											}
											// se noo achar o codigo bugou forte nossa logica gurizada
											if(!codBarrasEncontrado)
											{
												JOptionPane.showMessageDialog(janela, "Codigo de barras nao encotrado!","Prescricao",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												System.out.println("Bugou aqui na prescricao!");
											}
										}
									}else
									{
										JOptionPane.showMessageDialog(janela, "Campos Vazios, nao foi possivel prescrever o medicamento!","Prescricao",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
										System.out.println("Campos Vazios, nao foi possivel prescrever o medicamento!");
									}
									break;
								}
							}
						}else // PAINEL PRESCREVER
							if(e.getActionCommand().equals("Prescrever")) 
							{
								painelAtivo = 5;// definir qual painel esta ativo
								System.out.println("Mostrando painel prescrever...");
								this.janela.getCard().show(this.janela.getContentPane(), "tPrescrever");
								this.janela.setTitle("Prescricao"); 
								escondeMenu();
							}else // PAINEL ALTA
								if(e.getActionCommand().equals("Alta"))
								{
									painelAtivo = 3;// definir qual painel esta ativo
									System.out.println("Mostrando painel alta...");
									this.janela.getCard().show(this.janela.getContentPane(), "tAlta");
									this.janela.setTitle("Alta");
								}else // ATUALIZANDO MEDICAMENTO
									if(e.getActionCommand().equals("Atualizar"))
									{				
										String nomeMed = this.janela.getTelaMedicamentos().getFieldNome().getText();
										String codMed = this.janela.getTelaMedicamentos().getFieldCodBarras().getText();
										System.out.println("Atualizando medicamento...");
										
										// verificacoes
										if(!nomeMed.equals("") && alergiasMedicamento() && !codMed.equals(""))
										{
											Medicamento med = new Medicamento(codMed, nomeMed, mGluten, mFrutosMar, mDipirona, mPenicilina);
											if(mDAO.consultaMedicamentoExiste(codMed))
											{
												if(mDAO.atualizarMedicamentos(med))
												{
													JOptionPane.showMessageDialog(janela, "Medicamento atualizado!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
													this.janela.getTelaMedicamentos().limpaTela();
												}else
												{
													JOptionPane.showMessageDialog(janela, "Erro ao atualizar o medicamento!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												}
											}else
											{
												JOptionPane.showMessageDialog(janela, "Medicamento nao encontrado na base de dados!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
											}
										}else
										{
											JOptionPane.showMessageDialog(janela, "Campos em branco!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
										}
									}else // REMOVENDO MEDICAMENTO
										if(e.getActionCommand().equals("Remover"))
										{
											String codB = janela.getTelaMedicamentos().getFieldCodBarras().getText();
											// codigo em branco?
											if(!codB.equals(""))
											{
												// medicamento existe?
												if(mDAO.consultaMedicamentoExiste(codB))
												{
													// existe, entao remove
													if(mDAO.removeMedicamento(codB))
													{
														JOptionPane.showMessageDialog(janela, "Medicamento removido!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
														this.janela.getTelaMedicamentos().limpaTela();
													}else
													{
														JOptionPane.showMessageDialog(janela, "Nao foi possivel remover medicamento!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
													}
												}else // nao existe medicamento
												{
													JOptionPane.showMessageDialog(janela, "Medicamento nao esta cadastrado!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
												}
											}else
											{
												JOptionPane.showMessageDialog(janela, "Campo Vazio!\nNao foi possivel consultar medicamento!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
											}
											
											System.out.println("Removendo medicamento...");
										}else // CONSULTANDO MEDICAMENTO
											if(e.getActionCommand().equals("Consultar"))
											{
												System.out.println("Consultando medicamento...");
												String codB = this.janela.getTelaMedicamentos().getFieldCodBarras().getText();
												// codigo em branco?
												if(codB.equals(""))
												{
													JOptionPane.showMessageDialog(janela, "Campo Vazio!\nNao foi possivel consultar medicamento!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/error.png")));
												}else // codigo esta em branco
												{
													if(mDAO.consultaMedicamentoExiste(codB))
													{
														JOptionPane.showMessageDialog(janela, "Medicamento encontrado na base de dados!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/ok.png")));
													}else
													{
														JOptionPane.showMessageDialog(janela, "Medicamento nao encontrado na base de dados!","Medicamento",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
													}
												}
											}
		}
	
	
	// *-- LUKAS  MACHADO --*
	public boolean setAlergiasPaciente()
	{
		try {
			// ALERGIA GLUTEN
			if(this.janela.getTelaAdmissaoPacientes().getChkGluten().isSelected())
			{
				gluten = "S";
			}else
			{
				gluten = "N";
			}
			// ALERGIA DIPIRONA
			if(this.janela.getTelaAdmissaoPacientes().getChkDipirona().isSelected())
			{
				dipirona = "S";
			}else
			{
				dipirona = "N";
			}
			// ALERGIA FRUTOS DO MAR
			if(this.janela.getTelaAdmissaoPacientes().getChkFrutosDoMar().isSelected())
			{
				frutos = "S";
			}else
				
			{
				frutos = "N";
			}
			// ALERGIA PENICILINA
			if(this.janela.getTelaAdmissaoPacientes().getChkPenicilina().isSelected())
			{
				penicilina = "S";
			}else
			{
				penicilina = "N";
			}
			
			System.out.println("Cadastro de alergias concluido!");
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	
	// *-- LUKAS MACHADO --* // PREENCHE A LISTA DE INTERNADOS
	public void preencheInternados(ArrayList<Paciente> pacientesInt)
	{
		if(pacientesInt != null)
		{
			String conteudoNome = "";
			String conteudoData = "";
			String conteudoUnidade = "";
			String conteudoAlergia = "";
			
			for(Paciente paciente : pacientesInt)
			{
				conteudoNome = conteudoNome + paciente.getNome() + "\n";
				conteudoData = conteudoData + paciente.getDataNasc() + "\n";
				conteudoUnidade = conteudoUnidade + paciente.getUnidade() + "\n";
				conteudoAlergia = conteudoAlergia + verificaAlergias(paciente) + "\n";	
			}
			
			this.janela.getTelaInternados().getTextNome().setText(conteudoNome);
			this.janela.getTelaInternados().getTextData().setText(conteudoData);
			this.janela.getTelaInternados().getTextUnidade().setText(conteudoUnidade);
			this.janela.getTelaInternados().getTextAlergia().setText(conteudoAlergia);
		}else
		{
			JOptionPane.showMessageDialog(janela, "Nao ha pacientes internados!","Internados",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
		}
	}
	
	/* *--LUKAS MACHADO--*   VERIFICA ALERGIAS DO PACIENTE PARA COLOCAR NA LISTA DOS INTERNADOS */
	public String verificaAlergias(Paciente p)
	{
		String retorno = "";
		
		// alergia a gl ten
		if(p.getAlergiaGluten().equals("S"))
		{
			retorno = retorno + "Alergico a Gluten";
		}
		// alergia a frutos do mar
		if(p.getAlergiaFrutosMar().equals("S"))
		{
			if(retorno.equals(""))
			{
				retorno = retorno + "Alergico a Frutos do Mar";
			}
			else
			{
				retorno = retorno + "/Alergico a Frutos do Mar";
			}
		}
		// alergia dipirona
		if(p.getAlergiaDipirona().equals("S"))
		{
			if(retorno.equals(""))
			{
				retorno = retorno + "Alergico a Dipirona";
			}else
			{
				retorno = retorno + "/Alergico a Dipirona";
			}
		}
		// alergia a penicilina
		if(p.getAlergiaPenicilina().equals("S"))
		{
			if(retorno.equals(""))
			{
				retorno = retorno + "Alergico a Penicilina";
			}else
			{
				retorno = retorno + "/Alergico a Penicilina";
			}
			
		}
		return retorno;
	}
	
	// *--VITHOR DELAVI--* MEDICAMENTOS ALERGIAS
	public boolean alergiasMedicamento() {
		
		try {
		if(this.janela.getTelaMedicamentos().getChkGluten().isSelected()) 
		{
			mGluten = "S";
		}else
		{
			mGluten = "N";
		}
		if(this.janela.getTelaMedicamentos().getChkFrutosMar().isSelected())
		{
			mFrutosMar = "S";
		}else
		{
			mFrutosMar = "N";
		}
		if(this.janela.getTelaMedicamentos().getChkDipirona().isSelected()) 
		{
			mDipirona = "S";
		}else
		{
			mDipirona = "N";
		}
		if(this.janela.getTelaMedicamentos().getChkPenicilina().isSelected()) 
		{
			mPenicilina = "S";
		}else
		{
			mPenicilina = "N";
		}
		System.out.println("Testando Medicamento Cadastro de alergia!");
		return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	
	// esconde JMENUBAR quando em  telas 	// *-- LUKAS  MACHADO --*
	public void escondeMenu()
	{
		this.janela.gettMenuBar().setVisible(false);
	}

	// EVENTOS DE TECLAS
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	
	// usar esta fun  o para:
	/*  Ao digitar o CPF, deve-se percorrer o arquivo  lista-pacientes.txt  e procurar
		pelo CPF digitado.
		Se encontrar o CPF, deve-se carregar as demais informa  es na
		tela, como nome, data de nascimento e alergias do paciente. Essas
		informa  es carregas ficar o em campos protegidos de edi  o.
		Se n o encontrar o CPF, deve-se emitir uma mensagem no console
		e limpar o campo
	*/
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		/* 1. Campo cpf contem 11 d gitos?
		 *   1.1 Tem 11 d gitos! 
		 *       1.2 Ent o criaremos uma lista com os pacientes e iremos verificar 
		 *          1.3 O cpf se encontra nela?
		 *              1.4 Se encontra          
		 *              	1.5 Ent o coloca informa  es do usu rio
		 *          1.3.0 N o se encontra!
		 *                Limpamos o campo cpf! 
		 * 1.0 N o tem 11 d gitos!
		 * 	   N o faz nada!
		*/
		procuraMedicamento();
		procuraPaciente();
	
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		procuraMedicamento();
		procuraPaciente();
	}
	/*
	 * 1.6 O Campo medicamento 20 caracteres? ######
		 *                      // problema:   Nesta verifica  o n o   poss vel limpar o campo. N o existe regra de m nimo de caracteres para o c digo de barras.
		 *                        			   Nesse sentido, seria limpado o campo sempre que digitado algo, a n o ser que exista uma quantidade m nima de caracteres 
		 *                                     para ele iniciar a verifica  o. Por isso definimos um m nimo de 20 caracteres para nosso c digo de barras ser aceito e lido.
		 *                      1.7 Tem c digo?
		 *                          1.8 Cria lista de medicamentos
		 *                              1.8 Procura o c digo digitado na lista
		 *                                  1.9 Achou!
		 *                                      1.10 Coloca o nome medicamento ao lado
		 *                                  1.9.0 N o achou!
		 *                                        Limpa o campo
		 *                  1.6.0 Est  vazio!
		 *                        N o faz nada*/
	// UTILIZADA NO PRESCREVER KEY PRESSED
	public void procuraMedicamento()
	{
		String cdBarras = this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().getText();
		// verifica tamanho do c digo de barras
		if(cdBarras.length() == 20)
		{
			// c digo de barras t  ok
			boolean achouCodigo = false;
			ArrayList<Medicamento> listaMedicamentos = new ArrayList<Medicamento>();
			listaMedicamentos = mDAO.consultaMedicamentos();
			// verifica se existem medicamentos
			if(listaMedicamentos !=null)
			{
				//percorre a lista de medicamentos procurando o medicamento
				for(Medicamento m : listaMedicamentos)
				{
					// compara codigos
					if(m.getCodBarras().equals(cdBarras))
					{
						// coloca a informa  o do medicamento ao lado
						this.janela.getTelaPrescricao().getFieldNomeMedicamento().setText(m.getNome());
						achouCodigo = true;
						break;
					}
				}
				// se n o encontrou o c digo ent o limpa o campo
				if(!achouCodigo)
				{
					JOptionPane.showMessageDialog(janela, "Medicamento nao encontrado na base de dados!","Prescrever",0,new ImageIcon(ControleSistemaPrescricao.class.getResource("/imagens/warning.png")));
					System.out.println("Medicamento nao encontrado!");
					this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().setText("");// limpa campo c digo de barras
					this.janela.getTelaPrescricao().getFieldNomeMedicamento().setText("");// limpa campo nome medicamento
				}
			}else
			{
				// nao existem medicamentos cadastrados
				System.out.println("Nao existem medicamentos cadastrados!");
				this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().setText("");// limpa campo c digo de barras
				this.janela.getTelaPrescricao().getFieldNomeMedicamento().setText("");// limpa campo nome medicamento
			}
		}else
		{
			// se digitar mais de 20 
			if(cdBarras.length() > 20)
			{
				this.janela.getTelaPrescricao().getFieldCodBarrasMedicamento().setText("");// limpa campo c digo de barras
				this.janela.getTelaPrescricao().getFieldNomeMedicamento().setText("");// limpa campo nome medicamento
				System.out.println("Codigo invalido!");
			}
		}
	}
	
	// UTILIZADA NO PRESCREVER KEY PRESSED
	public void procuraPaciente() 
	{
		String cpf = this.janela.getTelaPrescricao().getFieldCpf().getText();
		// verifica se o cpf   v lido 
		if(cpf.length() == 11)
		{
			if(ehCPF(cpf))
			{
				// se tiver
				PacienteDAO paciente = new PacienteDAO();
				ArrayList<Paciente> listaPacientes = new ArrayList<Paciente>();
				listaPacientes = paciente.consultaPacientesInternados();
				boolean achouCpf = false;
				// percorre lista procurando o cpf para colocar as informa  es do paciente
				for(Paciente p : listaPacientes)
				{
					// procura cpf
					if(p.getCpf().equals(cpf))
					{
						// antes limpa o painel para evitar informa  es erradas
						this.janela.getTelaPrescricao().limpaVerificacaoCpf();
						// coloca o cpf pois a janela foi limpa
						this.janela.getTelaPrescricao().getFieldCpf().setText(cpf);
						// coloca as informa  es no JPanel
						this.janela.getTelaPrescricao().getFieldNome().setText(p.getNome()); // nome
						this.janela.getTelaPrescricao().getFieldDataNasc().setText(p.getDataNasc()); // data nascimento
						if(p.getAlergiaGluten().equals("S")) {this.janela.getTelaPrescricao().getChkGluten().setSelected(true);} // alergia gluten
						if(p.getAlergiaFrutosMar().equals("S")) {this.janela.getTelaPrescricao().getChkFrutosDoMar().setSelected(true);} // alergia frutos
						if(p.getAlergiaDipirona().equals("S")) {this.janela.getTelaPrescricao().getChkDipirona().setSelected(true);} // alergia dipirona
						if(p.getAlergiaPenicilina().equals("S")) {this.janela.getTelaPrescricao().getChkPenicilina().setSelected(true);} // alergia penicilina
						achouCpf = true;
						break;
					}
				}
				// se n o achou cpf limpa o campo
				if(!achouCpf) 
				{
					this.janela.getTelaPrescricao().limpaVerificacaoCpf();
					System.out.println("CPF nao encontrado!");
				}
			}else
			{
				System.out.println("CPF invalido!");
				this.janela.getTelaPrescricao().limpaVerificacaoCpf();
			}
		}else
		{
			// se o usuario digitar mais de 11 caracteres
			if(cpf.length() > 11)
			{
				System.out.println("CPF invalido!");
				this.janela.getTelaPrescricao().limpaVerificacaoCpf();
			}
		}
	}
	
	// retorna as alergias do paciente dependendo do medicamento
	public boolean pacienteAlergico(Medicamento med)
	{
		boolean alergico = false;
		// verifica alergias do paciente
		
		// al rgico a gl ten
		if(this.janela.getTelaPrescricao().getChkGluten().isSelected() && med.getCbGluten().equals("S"))
		{
			return true;
		}
		
		if(this.janela.getTelaPrescricao().getChkFrutosDoMar().isSelected() && med.getCbFrutosMar().equals("S"))
		{
			return true;
		}
		
		if(this.janela.getTelaPrescricao().getChkDipirona().isSelected() && med.getCbDipirona().equals("S"))
		{
			return true;
		}
		
		if(this.janela.getTelaPrescricao().getChkPenicilina().isSelected() && med.getCbPenicilina().equals("S"))
		{
			return true;
		}
		// se nao passou por nenhuma ele n o tem alergias ao medicamento
		return alergico;
	}
	
	//
	public boolean ehCPF(String CPF) 
	{
        // considera-se erro CPF's formados por uma sequencia de numeros iguais
        if (CPF.equals("00000000000") ||
            CPF.equals("11111111111") ||
            CPF.equals("22222222222") || CPF.equals("33333333333") ||
            CPF.equals("44444444444") || CPF.equals("55555555555") ||
            CPF.equals("66666666666") || CPF.equals("77777777777") ||
            CPF.equals("88888888888") || CPF.equals("99999999999") ||
            (CPF.length() != 11))
            return(false);

        char dig10, dig11;
        int sm, i, r, num, peso;

        // "try" - protege o codigo para eventuais erros de conversao de tipo (int)
        try {
        // Calculo do 1o. Digito Verificador
            sm = 0;
            peso = 10;
            for (i=0; i<9; i++) {
        // converte o i-esimo caractere do CPF em um numero:
        // por exemplo, transforma o caractere '0' no inteiro 0
        // (48 eh a posicao de '0' na tabela ASCII)
            num = (int)(CPF.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                dig10 = '0';
            else dig10 = (char)(r + 48); // converte no respectivo caractere numerico

        // Calculo do 2o. Digito Verificador
            sm = 0;
            peso = 11;
            for(i=0; i<10; i++) {
            num = (int)(CPF.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
            }

            r = 11 - (sm % 11);
            if ((r == 10) || (r == 11))
                 dig11 = '0';
            else dig11 = (char)(r + 48);

        // Verifica se os digitos calculados conferem com os digitos informados.
            if ((dig10 == CPF.charAt(9)) && (dig11 == CPF.charAt(10)))
                 return(true);
            else return(false);
                } catch (InputMismatchException erro) {
                return(false);
            }
	       }
}
